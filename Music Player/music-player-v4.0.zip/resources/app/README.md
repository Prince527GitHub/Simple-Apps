# Simple Apps
 A repo full of apps (ex: music player, video player, etc)
